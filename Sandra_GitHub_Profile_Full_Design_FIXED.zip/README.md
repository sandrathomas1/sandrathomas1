<!--
  Sandra Thomas · GitHub Profile
  Dark dashboard palette: #0D1117 · #161B22 · #FF79C6 · #58A6FF · #2DD4BF
  All main graphics are stored locally in assets/ for reliable rendering.
-->

<div align="center">
  <img src="assets/header.png" width="100%" alt="Sandra Thomas — Software Developer, Frappe and ERPNext Specialist" />
  <p>
    <a href="https://www.linkedin.com/in/sandrathomas404"><img src="https://img.shields.io/badge/LinkedIn-161B22?style=flat-square&logo=linkedin&logoColor=58A6FF&labelColor=161B22" alt="LinkedIn" /></a>
    <a href="mailto:sandrathomass404@gmail.com"><img src="https://img.shields.io/badge/Email-161B22?style=flat-square&logo=gmail&logoColor=FF79C6&labelColor=161B22" alt="Email" /></a>
    <a href="https://www.instagram.com/sandra_._theresa/"><img src="https://img.shields.io/badge/Instagram-161B22?style=flat-square&logo=instagram&logoColor=2DD4BF&labelColor=161B22" alt="Instagram" /></a>
  </p>
</div>

### 👩‍💻 About me

I'm a **Software Developer and Senior Techno-Functional Consultant** focused on practical ERP solutions, enterprise web applications and process automation.

- **I build:** Frappe/ERPNext applications, DocTypes, workflows, reports and print formats.
- **I integrate:** REST APIs, Meta WhatsApp Business API and payment gateways.
- **I deliver:** ERPNext implementations, data migration, go-live support and technical documentation.

---

### 📊 Developer dashboard

<img src="assets/dashboard.png" width="100%" alt="Portfolio snapshot: 11 public GitHub repositories, 9 followers, 6 featured projects, professional development since 2021, and core technologies" />

<sub>Portfolio snapshot • GitHub profile counts checked on 10 November 2026. These are static figures, not live GitHub activity statistics.</sub>

---

### 🛠️ Languages & technologies

<p align="left">
  <a href="https://www.python.org/"><img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/python/python-original.svg" width="35" height="35" title="Python" alt="Python" /></a>&nbsp;&nbsp;
  <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript"><img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/javascript/javascript-original.svg" width="35" height="35" title="JavaScript" alt="JavaScript" /></a>&nbsp;&nbsp;
  <a href="https://vuejs.org/"><img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/vuejs/vuejs-original.svg" width="35" height="35" title="Vue.js" alt="Vue.js" /></a>&nbsp;&nbsp;
  <a href="https://frappe.io/framework"><img src="assets/frappe-mark.png" width="35" height="35" title="Frappe Framework" alt="Frappe Framework" /></a>&nbsp;&nbsp;
  <a href="https://erpnext.com/"><img src="https://cdn.jsdelivr.net/gh/selfhst/icons/svg/frappe-erpnext.svg" width="35" height="35" title="ERPNext" alt="ERPNext" /></a>&nbsp;&nbsp;
  <a href="https://mariadb.org/"><img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/mariadb/mariadb-original.svg" width="35" height="35" title="MariaDB" alt="MariaDB" /></a>&nbsp;&nbsp;
  <a href="https://developers.facebook.com/docs/whatsapp/"><img src="https://cdn.simpleicons.org/whatsapp/25D366" width="35" height="35" title="Meta WhatsApp API" alt="WhatsApp API" /></a>&nbsp;&nbsp;
  <a href="https://git-scm.com/"><img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/git/git-original.svg" width="35" height="35" title="Git" alt="Git" /></a>&nbsp;&nbsp;
  <a href="https://github.com/"><img src="https://cdn.simpleicons.org/github/58A6FF" width="35" height="35" title="GitHub" alt="GitHub" /></a>
</p>

**Languages & framework:** Python · JavaScript · Vue.js · Frappe · ERPNext  
**Database & tools:** MariaDB · Git · GitHub  
**Integrations:** REST APIs · WhatsApp Business API · Payment Gateways

---

### 🚀 Featured projects

<img src="assets/projects.png" width="100%" alt="Six featured projects: DCMS, Truefroot, Eyeco, TriE, Grillax and Visaguy" />

<details>
<summary><b>View project details</b></summary>

#### 01 · DCMS — Document Control Management System
Developed with **Vue.js and Frappe Framework** for document registers, revisions, approvals, transmittals, traceability and controlled document lifecycles.

#### 02 · Truefroot — Manufacturing ERP
Implemented **ERPNext** for fruit pulp production, including manufacturing, inventory, purchasing, sales, accounting and HR.

#### 03 · Eyeco — Optical Order Management
Developed a front-end order-taking system with **ERPNext backend integration** for sales, inventory and accounting.

#### 04 · TriE — Car Wash Subscription System
Built a subscription-based solution with automated service jobs, **Meta WhatsApp API**, payment gateway integration, sales and HRMS.

#### 05 · Grillax — Restaurant ERP
Developed a restaurant management application with custom **POS**, hospitality, manufacturing, inventory and accounting workflows in ERPNext.

#### 06 · Visaguy — CRM & Visa Processing
Implemented **ERPNext CRM** to streamline lead generation, customer management and visa processing workflows.

</details>

---

### 💼 Professional experience

<img src="assets/experience.png" width="100%" alt="Career timeline showing Senior Techno-Functional Consultant, Frappe Technologies, Benzy Infotech and Tridz Technologies" />

<details>
<summary><b>View responsibilities and contributions</b></summary>

#### Senior Techno-Functional Consultant · Current role
Working on enterprise software, ERPNext customization, Frappe application development, integrations and business process automation.

#### Frappe Technologies Pvt Ltd · Support Consultant
`Oct 2025 – Jul 2026`

- Provided functional and technical support for **Accounts, HR, Stock, Buying and Selling**.
- Managed customer tickets and investigated Frappe/ERPNext issues.
- Contributed to ERPNext user guides, documentation and system updates.
- Collaborated with internal teams to improve usability and documentation quality.

#### Benzy Infotech Pvt Ltd · Software Developer
`Aug 2025 – Sep 2025`

- Developed APIs for seamless data exchange and automation.
- Built and maintained airline software applications.
- Focused on code quality, performance and security.

#### Tridz Technologies Pvt Ltd, Bangalore · Software Developer
`Aug 2021 – Jun 2025`

- Developed custom Frappe and ERPNext **DocTypes, scripts, reports and workflows**.
- Supported ERPNext implementation, data import and go-live activities.
- Created SOPs, training materials and user manuals.
- Provided technical and functional support after implementation.

</details>

---

### 🎓 Education & certification

<img src="assets/education.png" width="100%" alt="Bachelor of Computer Application, 2017 to 2020; ERPGulf Training for Accountants, Udemy, May 2023" />

**Certificate:** [ERPGulf Training for Accountants — Udemy](https://www.udemy.com/certificate/UC-c23d9088-5b68-48cf-b6fb-dd1f32b8f5b6/)

---

<div align="center">
  <b>🤝 Let's connect</b>
  <p>Interested in Frappe, ERPNext, automation or enterprise integrations?</p>
  <p><a href="https://www.linkedin.com/in/sandrathomas404">LinkedIn</a> · <a href="mailto:sandrathomass404@gmail.com">Email</a> · <a href="https://www.instagram.com/sandra_._theresa/">Instagram</a></p>
  <sub>Thanks for visiting my GitHub profile.</sub>
</div>
